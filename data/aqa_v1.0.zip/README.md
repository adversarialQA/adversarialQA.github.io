# AdversarialQA

This is Adversarial QA, version 1.0. Date: September 23, 2020

If you have any questions, comments or suggestions, contact <m.bartolo@cs.ucl.ac.uk>

If you use this dataset in your own work, please cite the paper.

Paper: https://arxiv.org/abs/2002.00293

Github: https://github.com/maxbartolo.com/adversarialQA


== Details ==

1. The test sets have had answers removed.

2. The `squad_splits` directory contain the dev and test splits of the SQuAD1.1 dev set that we used in the paper with majority vote (i.e. single ground truth) answers.

